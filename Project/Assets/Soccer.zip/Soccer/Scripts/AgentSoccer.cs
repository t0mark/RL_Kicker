using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Policies;

public enum Team
{
    Blue = 0,
    Purple = 1
}

public class AgentSoccer : Agent
{
    // Note that that the detectable tags are different for the blue and purple teams. The order is
    // * ball
    // * own goal
    // * opposing goal
    // * wall
    // * own teammate
    // * opposing player

    public enum Position
    {
        Striker,
        Defender,
        Goalie,
        Generic
    }

    [HideInInspector]
    public Team team;
    float m_KickPower;
    // The coefficient for the reward for colliding with a ball. Set using curriculum.
    float m_BallTouch;
    public Position position;

    const float k_Power = 2000f;
    float m_Existential;
    float m_LateralSpeed;
    float m_ForwardSpeed;
    SoccerEnvController m_EnvController;
    Transform m_OwnGoal;

    [Header("Role Settings")]
    [SerializeField]
    float m_GoalieExistentialRewardScale = 1f;

    [SerializeField]
    float m_StrikerExistentialPenaltyScale = 1f;

    [Header("Defender Role Settings")]
    [SerializeField]
    float m_DefenderExistentialBonus = 0.5f;

    [SerializeField]
    float m_DefenderAlignmentWeight = 0.6f;

    [SerializeField]
    float m_DefenderDistanceWeight = 0.4f;

    [SerializeField]
    float m_DefenderShapeRewardScale = 0.02f;

    [SerializeField]
    float m_DefenderOptimalDistanceRatio = 0.55f;

    [SerializeField]
    float m_DefenderMinDistance = 4f;

    [SerializeField]
    float m_DefenderOutOfPositionPenalty = 0.02f;


    [HideInInspector]
    public Rigidbody agentRb;
    SoccerSettings m_SoccerSettings;
    BehaviorParameters m_BehaviorParameters;
    public Vector3 initialPos;
    public float rotSign;

    EnvironmentParameters m_ResetParams;

    [HideInInspector]
    public bool manualOverride = false;

    // Player controller for shared behavior
    SoccerPlayerController m_PlayerController;

    public bool IsDribbling => m_PlayerController != null && m_PlayerController.IsDribbling;

    public override void Initialize()
    {
        m_EnvController = GetComponentInParent<SoccerEnvController>();
        if (m_EnvController != null)
        {
            m_Existential = 1f / m_EnvController.MaxEnvironmentSteps;
        }
        else
        {
            m_Existential = 1f / MaxStep;
        }

        m_BehaviorParameters = gameObject.GetComponent<BehaviorParameters>();
        if (m_BehaviorParameters.TeamId == (int)Team.Blue)
        {
            team = Team.Blue;
            initialPos = new Vector3(transform.position.x - 5f, .5f, transform.position.z);
            rotSign = 1f;
        }
        else
        {
            team = Team.Purple;
            initialPos = new Vector3(transform.position.x + 5f, .5f, transform.position.z);
            rotSign = -1f;
        }
        CacheGoalReference();

        // Initialize or get player controller
        m_PlayerController = GetComponent<SoccerPlayerController>();
        if (m_PlayerController == null)
        {
            m_PlayerController = gameObject.AddComponent<SoccerPlayerController>();
        }

        // Set speeds based on position
        if (position == Position.Goalie)
        {
            m_LateralSpeed = 1.0f;
            m_ForwardSpeed = 1.0f;
        }
        else if (position == Position.Striker)
        {
            m_LateralSpeed = 0.3f;
            m_ForwardSpeed = 1.3f;
        }
        else if (position == Position.Defender)
        {
            m_LateralSpeed = 0.7f;
            m_ForwardSpeed = 1.1f;
        }
        else
        {
            m_LateralSpeed = 0.3f;
            m_ForwardSpeed = 1.0f;
        }

        m_PlayerController.SetSpeeds(m_LateralSpeed, m_ForwardSpeed);
        m_PlayerController.SetTeam(team);

        m_SoccerSettings = FindFirstObjectByType<SoccerSettings>();
        agentRb = GetComponent<Rigidbody>();

        m_ResetParams = Academy.Instance.EnvironmentParameters;
    }

    public void MoveAgent(ActionSegment<int> act)
    {
        var dirToGo = Vector3.zero;
        var rotateDir = Vector3.zero;

        m_KickPower = 0f;

        var forwardAxis = act[0];
        var rightAxis = act[1];
        var rotateAxis = act[2];

        switch (forwardAxis)
        {
            case 1:
                dirToGo = transform.forward * m_ForwardSpeed;
                m_KickPower = 1f;

                // Start kick charge when dribbling
                if (m_PlayerController.IsDribbling && !m_PlayerController.IsChargingKick)
                {
                    m_PlayerController.StartKickCharge();
                }
                break;
            case 2:
                dirToGo = transform.forward * -m_ForwardSpeed;

                // Execute kick if charging
                if (m_PlayerController.IsChargingKick)
                {
                    m_PlayerController.ExecuteChargedKick();
                }
                break;
        }

        switch (rightAxis)
        {
            case 1:
                dirToGo = transform.right * m_LateralSpeed;
                break;
            case 2:
                dirToGo = transform.right * -m_LateralSpeed;
                break;
        }

        switch (rotateAxis)
        {
            case 1:
                rotateDir = transform.up * -1f;
                break;
            case 2:
                rotateDir = transform.up * 1f;
                break;
        }

        m_PlayerController.Rotate(rotateDir, 100f);
        m_PlayerController.Move(dirToGo, m_SoccerSettings.agentRunSpeed);
    }

    public override void OnActionReceived(ActionBuffers actionBuffers)

    {
        if (manualOverride)
        {
            return;
        }

        if (position == Position.Goalie)
        {
            // Existential bonus for Goalies.
            AddReward(m_Existential * m_GoalieExistentialRewardScale);
        }
        else if (position == Position.Striker)
        {
            // Existential penalty for Strikers
            AddReward(-m_Existential * m_StrikerExistentialPenaltyScale);
        }
        else if (position == Position.Defender)
        {
            AddReward(m_Existential * m_DefenderExistentialBonus);
            AddReward(ComputeDefenderShapeReward());
        }
        MoveAgent(actionBuffers.DiscreteActions);

        // Update dribble
        m_PlayerController.UpdateDribble();
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var discreteActionsOut = actionsOut.DiscreteActions;
        //forward
        if (Input.GetKey(KeyCode.W))
        {
            discreteActionsOut[0] = 1;
        }
        if (Input.GetKey(KeyCode.S))
        {
            discreteActionsOut[0] = 2;
        }
        //rotate
        if (Input.GetKey(KeyCode.A))
        {
            discreteActionsOut[2] = 1;
        }
        if (Input.GetKey(KeyCode.D))
        {
            discreteActionsOut[2] = 2;
        }
        //right
        if (Input.GetKey(KeyCode.E))
        {
            discreteActionsOut[1] = 1;
        }
        if (Input.GetKey(KeyCode.Q))
        {
            discreteActionsOut[1] = 2;
        }
    }
    /// <summary>
    /// Used to provide a "kick" to the ball.
    /// </summary>
    void OnCollisionEnter(Collision c)
    {
        var force = k_Power * m_KickPower;
        if (position == Position.Goalie)
        {
            force = k_Power;
        }
        if (c.gameObject.CompareTag("ball"))
        {
            AddReward(.2f * m_BallTouch);

            // Only physically push ball when not dribbling
            if (!m_PlayerController.IsDribbling)
            {
                var dir = c.contacts[0].point - transform.position;
                dir = dir.normalized;
                c.gameObject.GetComponent<Rigidbody>().AddForce(dir * force);
            }
        }

        // Tackle handling is now done in SoccerPlayerController
    }

    public override void OnEpisodeBegin()
    {
        m_BallTouch = m_ResetParams.GetWithDefault("ball_touch", 0);
        CacheGoalReference();
    }

    void CacheGoalReference()
    {
        if (m_EnvController == null)
        {
            m_EnvController = GetComponentInParent<SoccerEnvController>();
        }
        if (m_EnvController != null)
        {
            m_OwnGoal = m_EnvController.GetGoalTransform(team);
        }
    }

    float ComputeDefenderShapeReward()
    {
        if (m_EnvController == null)
        {
            return 0f;
        }

        var goal = m_OwnGoal;
        if (goal == null)
        {
            CacheGoalReference();
            goal = m_OwnGoal;
            if (goal == null)
            {
                return 0f;
            }
        }

        var ballTransform = m_EnvController.BallTransform;
        if (ballTransform == null)
        {
            return 0f;
        }

        var goalToBall = ballTransform.position - goal.position;
        var goalToAgent = transform.position - goal.position;

        if (goalToBall.sqrMagnitude < 0.01f || goalToAgent.sqrMagnitude < 0.01f)
        {
            return 0f;
        }

        var alignment = Mathf.Clamp01(Vector3.Dot(goalToAgent.normalized, goalToBall.normalized));

        var targetDistance = Mathf.Clamp(goalToBall.magnitude * m_DefenderOptimalDistanceRatio,
            m_DefenderMinDistance, m_EnvController.DefensiveShellRadius);

        var distanceError = Mathf.Abs(goalToAgent.magnitude - targetDistance);
        var distanceReward = Mathf.Clamp01(1f - distanceError / Mathf.Max(targetDistance, 0.001f));

        var shapeReward = (alignment * m_DefenderAlignmentWeight) +
                          (distanceReward * m_DefenderDistanceWeight);

        shapeReward *= m_DefenderShapeRewardScale;

        if (goalToAgent.magnitude > m_EnvController.DefensiveMaxRadius)
        {
            shapeReward -= m_DefenderOutOfPositionPenalty;
        }

        return shapeReward;
    }
}
